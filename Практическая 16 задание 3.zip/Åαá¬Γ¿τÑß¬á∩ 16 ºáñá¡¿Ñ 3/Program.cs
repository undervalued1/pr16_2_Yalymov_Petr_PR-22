﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.IO;
namespace Практическая_16_задание_3
{
    class Program
    {

        static void Main(string[] args)
        {


            double[] array;

            Console.WriteLine("Выберите способ ввода массива:");
            Console.WriteLine("1. Ввести вручную");
            Console.WriteLine("2. Прочитать из файла");         //Test.txt-название файла для тестирования
            var choice = Console.ReadLine();

            if (choice == "1")
            {
                array = InputArrayManually();
            }
            else if (choice == "2")
            {
                array = InputArrayFromFile();
            }
            else
            {
                Console.WriteLine("Неверный выбор. Завершение программы.");
                return;
            }

            ProcessArray(array);
            Console.ReadKey();

        }
        static double[] InputArrayManually()
        {
            Console.WriteLine("Введите элементы массива, разделенные запятой:");
            var input = Console.ReadLine();
            return input.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => double.Parse(s, CultureInfo.InvariantCulture))
                        .ToArray();
        }

        static double[] InputArrayFromFile()
        {
            Console.WriteLine("Введите путь к файлу:");
            var filePath = Console.ReadLine();

            try
            {
                var lines = File.ReadAllLines(filePath);
                return lines.SelectMany(line => line.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
                            .Select(s => double.Parse(s, CultureInfo.InvariantCulture))
                            .ToArray();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Ошибка при чтении файла: {e.Message}");
                return new double[0];
            }
        }

        static void ProcessArray(double[] array)
        {
            if (array.Length == 0)
            {
                Console.WriteLine("Массив пуст или некорректен.");
                return;
            }
            var frequencyDict = array.GroupBy(x => x)
                                     .ToDictionary(g => g.Key, g => g.Count());

            Console.WriteLine("Число - Частота");
            foreach (var kvp in frequencyDict)
            {
                Console.WriteLine($"{kvp.Key} - {kvp.Value}");
            }
            var newArray = frequencyDict.Select(kvp => kvp.Key * kvp.Value).ToArray();

            Console.WriteLine("Новый массив:");
            foreach (var number in newArray)
            {
                Console.WriteLine(number);
            }
        }
    }
}
